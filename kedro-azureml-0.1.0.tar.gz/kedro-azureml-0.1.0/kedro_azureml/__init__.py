__version__ = "0.1.0"

import warnings

warnings.filterwarnings("ignore", module="azure.ai.ml")
